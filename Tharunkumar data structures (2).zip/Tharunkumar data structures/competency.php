<?php
// Include the session.php file to enforce session-based authentication
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Data structures</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Center the content */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            flex-direction: column; /* Added to make the content stack vertically */
        }

        /* Style the h3 element */
        h3 {
            font-size: 36px; /* Adjust the font size as needed */
            color: black;
            text-align: center;
        }

        /* Style the parrot image */
        .parrot {
            margin-top: 20px; /* Added margin to separate h3 and image */
        }

        /* Style the competency buttons */
        .difficulty {
            display: flex;
            flex-direction: column; /* Stack buttons vertically */
            align-items: center; /* Center the buttons horizontally */
            margin-top: 20px; /* Added margin to separate image and buttons */
        }

        .btn {
            text-decoration: none;
            padding: 15px 30px; /* Increase padding for larger buttons */
            font-size: 18px; /* Increase font size for larger buttons */
            background-color: #858C94; /* Set background color to #858C94 */
            color: #fff;
            border-radius: 5px;
            font-weight: bold;
            margin-bottom: 10px; /* Added margin between buttons */
        }
    </style>
</head>
<body>
    <header>
        <h2 class="logo">Data structures</h2>
        <nav class="navigation">
            <a href="competency.php">Home</a>
            <a href="profile.php">Profile</a>
            <a href="login.html" class="btnlogout">Logout</a>
        </nav>
    </header>

    <h3>Choose your competency</h3>

    <div class="parrot">
        <img src="parrot.png" alt="parrot" />
    </div>

    <nav class="difficulty">
        <a href="topic.php" class="btn">BEGINNER</a>
        <a href="topicinter.php" class="btn">INTERMEDIATE</a>
        <a href="topicexpert.php" class="btn">EXPERT</a>
    </nav>
</body>
</html>
