-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2024 at 10:00 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `javaboi`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL,
  `question` text DEFAULT NULL,
  `answer_1` text DEFAULT NULL,
  `answer_2` text DEFAULT NULL,
  `answer_3` text DEFAULT NULL,
  `answer_4` text DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`id`, `question`, `answer_1`, `answer_2`, `answer_3`, `answer_4`, `correct_answer`) VALUES
(1, 'What will be the size of the following structure?\r\n#include <stdio.h>\r\nstruct temp {\r\n  int a[10];\r\n  char p;\r\n};', '5\r\n', '11', '41', '44', 4),
(2, 'Select the Valid Statement', 'char[] ch = new char(5)', 'char[] ch = new char[5]', 'char[] ch = a new char()', 'char[] ch = new char[]', 2),
(3, 'when an array is passed to a method, what does the method receive?', 'the reference of the array', 'a copy of the array', 'length of an array', 'copy of the first elements', 1),
(4, 'Which data structure is used to check a palindrome?\r\n', ' Linked List', ' Stack', 'Queue', 'Tree', 3),
(5, 'Which among the following sorting algorithm is the most optimal one to sort a random linked list?\r\n Merge sort', 'Merge sort', ' Insertion sort', 'Quick sort', 'Heap sort', 1),
(6, ' Binary Search can be categorized into which of the following?\r\n', 'Brute Force technique', 'Divide and conquer', 'Greedy algorithm', 'Dynamic programming', 2),
(7, 'How long the following loop runs?\r\nfor(x = 1; x = 3; x++)', 'Three times\r\n', ' Four times', 'Forever', ' Never ', 4),
(8, 'Which is the logical or mathematical model of a particular organization of a data?\r\n\r\na) structure\r\nb) function\r\nc) variable\r\nd) data structure\r\n', 'structure', 'function', 'variable', ' data structure\r\n', 4),
(9, 'Which of these cannot be used for a variable name in Java?', 'identifier & keyword', 'identifier', 'keyword', 'none of the mentioned', 3),
(10, ' What will be the output of the following piece of code?\r\n#include <stdio.h>\r\n\r\nint main() {\r\n  int value = 0;\r\n  if(value)\r\n    printf(\"well done\");\r\n  printf(\"Algbly\");\r\n  return 0;\r\n}', 'well done \r\n', 'Algbly', 'complier error', 'None of these', 2),
(11, 'When an array can be declared ?\r\n', 'At compile Time\r\n', ' At run Time', 'At Compile or Run time', 'In program', 3),
(12, 'Which of the following highly uses the concept of an array?', 'Binary Search tree\r\n', 'Caching', 'Spatial locality', 'Scheduling of Processes', 3),
(13, 'Which arrays provide you with a more raw access to the objects\r\n\r\n', 'pointer based array', 'vector based array', 'Multidimensional Array', '2-D array\r\n', 1),
(14, 'Which one of the following is the process of inserting an element in the stack?Which one of the following is the process of inserting an element in the stack?', 'Insert', 'Add\nPush', 'PUSH', 'None of the above\n', 2),
(15, 'What will be the value of the digit?\r\n#include <stdio.h>\r\n\r\nint main() {\r\n  int digit = 0;\r\n  for(; digit <= 9; )\r\ndigit++;\r\n digit *= 2;\r\n--digit;\r\n  return 0;\r\n}', '-1\r\n', '17', '19', ' 16', 4),
(16, 'Which exception is thrown when Java is out of memory?', 'MemoryError', 'OutOfMemoryError', 'MemoryOutOfBoundsException', 'MemoryFullException', 2),
(17, 'What is the output of the below code?\r\n\r\n#include <stdio.h>  \r\nint main()  \r\n{  \r\n   int arr[5]={10,20,30,40,50};  \r\n   printf(\"%d\", arr[5]);  \r\n  \r\n    return 0;  \r\n}  ', 'Garbage value\r\n\r\n', '10\r\n', '50', 'None of the above', 1),
(18, 'Which of these keywords is used to define interfaces in Java?', 'intf', 'Intf', 'interface', 'Interf', 3),
(19, 'Which of the following is a superclass of every class in Java?', 'ArrayList', 'Abstract class', 'Object class', 'String', 3),
(20, 'If the elements \'1\', \'2\', \'3\' and \'4\' are added in a stack, so what would be the order for the removal?', '1234', '2134', '4321', 'None of the above', 3),
(21, ' A linear data structure in which insertion and deletion operations can be performed from both the ends is___', 'Queue', 'Deque', 'Priority queue', 'Circular queue', 3),
(22, 'Which of these statements is incorrect about Thread?', 'start() method is used to begin execution of the thread', 'run() method is used to begin execution of a thread before start() method in special cases', 'A thread can be formed by implementing Runnable interface only', 'A thread can be formed by a class that extends Thread class', 2),
(23, 'Which of the following data structure allows you to insert the elements from both the ends while deletion from only one end?', 'Input-restricted queue', 'Output-restricted queue', 'Priority queue', 'None of the above', 4),
(24, 'Which one of the following techniques is not used in the Binary tree?', 'Randomized traversal', 'Preorder traversal', 'Postorder traversal', 'Inorder traversal', 2),
(25, 'Why do we prefer Red Black tree over AVL tree?', 'Red Black trees are not strictly balanced', 'Red black tree requires lesser rotations than AVL tree.', 'AVL tree needs more space to store the balance factor.', 'Both b and c', 3),
(26, 'What is the extension of java code files?', '.js', '.txt', '.class', '.java', 4),
(27, 'Which of these are selection statements in Java?', 'break', 'continue', 'for()', 'if()', 4),
(28, 'Which of these keywords is used to define interfaces in Java?', 'intf', 'Intf', 'interface', 'Interf', 3),
(29, 'Which of the following is a superclass of every class in Java?', 'ArrayList', 'Abstract class', 'Object class', 'String', 3),
(30, 'Which of the following creates a List of 3 visible items and multiple selections enabled?', 'new List(false, 3)', 'new List(3, true)', 'new List(true, 3)', 'new List(3, false)', 2);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questionsexp`
--

CREATE TABLE `quiz_questionsexp` (
  `id` int(11) NOT NULL,
  `question` text DEFAULT NULL,
  `answer_1` text DEFAULT NULL,
  `answer_2` text DEFAULT NULL,
  `answer_3` text DEFAULT NULL,
  `answer_4` text DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questionsexp`
--

INSERT INTO `quiz_questionsexp` (`id`, `question`, `answer_1`, `answer_2`, `answer_3`, `answer_4`, `correct_answer`) VALUES
(1, 'The data structure required to check whether an expression contains a balanced parenthesis is?', 'Queue', 'Stack', 'Tree', ' Array', 2),
(2, 'Which of the following statement(s) about stack data structure is/are NOT correct?', 'Top of the Stack always contain the new node', 'Stack is the FIFO data structure', 'Null link is present in the last node at the bottom of the stack', ' Linked List are used for implementing Stacks', 2),
(3, 'Which of the following application makes use of a circular linked list?', ' Recursive function calls', 'Undo operation in a text editor', 'Implement Hash Tables', 'Allocating CPU to resources', 4),
(4, 'Which algorithm is used in the top tree data structure?', 'Backtracking', 'Divide and Conque', ' Branch', 'Greedy', 2),
(5, 'Which of the following data structure can provide efficient searching of the elements?', 'binary search tree', ' unordered lists', '2-3 tree', 'treap', 3),
(6, ' What is the use of the bin data structure?', 'to have efficient traversal', 'to have efficient region query', 'to have efficient deletion', 'to have efficient insertion', 2);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questionsint`
--

CREATE TABLE `quiz_questionsint` (
  `id` int(11) NOT NULL,
  `question` text DEFAULT NULL,
  `answer_1` text DEFAULT NULL,
  `answer_2` text DEFAULT NULL,
  `answer_3` text DEFAULT NULL,
  `answer_4` text DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_questionsint`
--

INSERT INTO `quiz_questionsint` (`id`, `question`, `answer_1`, `answer_2`, `answer_3`, `answer_4`, `correct_answer`) VALUES
(1, 'What data structure is used for implementing recursion?', 'Queue', 'Stack', ' Linked List', ' Tree', 2),
(2, 'In a binary search tree, which traversal visits the nodes in ascending order?', 'Preorder', 'Inorder', 'Postorder', 'Level order', 2),
(3, 'What is the time complexity of finding an element in a balanced binary search tree (BST)?', 'O(1)', 'O(log n)', 'O(n)', 'O(n log n)', 2),
(4, 'Which data structure is used for implementing a LIFO (Last-In-First-Out) order of elements?', 'Queue', 'Linked List', 'Stack', 'Heap', 3),
(5, 'hich data structure is best for implementing a dictionary with dynamic resizing?', 'Array', 'Linked List', ' Hash Table', 'Binary Search Tree', 3),
(6, 'The prefix form of A-B/ (C * D ^ E) is?', ' -A/B*C^DE\r\n', '-A/BC*^DE', '-ABCD*^DE', '-/*^ACBDE', 1),
(7, 'Which of the following application makes use of a circular linked list?', 'Recursive function calls\r\n ', ' Undo operation in a text editor', 'Implement Hash Tables', 'Allocating CPU to resources', 4),
(8, 'Which of the following is true about the anonymous inner class?', 'It has only methods', 'Objects can\'t be created', 'It has a fixed class name', 'It has no class name', 4),
(9, 'A data structure in which elements can be inserted or deleted at/from both ends but not in the middle is?', 'Priority queue', 'Dequeue', 'Circular queue', 'Queue', 2),
(10, ' What are the disadvantages of arrays?', 'Index value of an array can be negative', 'Elements are sequentially accessed', 'Data structure like queue or stack cannot be implemented', 'There are chances of wastage of memory space if elements inserted in an array are lesser than the allocated size', 2),
(11, 'Which one of the following is not an access modifier?', 'Protected', 'Void', 'Public', 'Private', 2),
(12, 'What is the numerical range of a char data type in Java?', '0 to 256', '-128 to 127', '0 to 65535', '0 to 32767', 3),
(13, 'Which class provides system independent server side implementation?', 'Server', 'ServerReader', 'Socket', 'ServerSocket', 4),
(14, 'Which of the following is the hashing function for separate chaining?', 'H(x)=(hash(x)+f(i)) mod table size\r\n', ' H(x)=hash(x)+i2 mod table size', 'H(x)=x mod table size', 'H(x)=x mod (table size * 2)', 3),
(15, 'What is the size of a C structure?', 'C structure is always 128 bytes\r\n', 'Size of C structure is the totatl bytes of all elements of structure', 'Size of C structure is the size of largest elements', 'None of the above', 2),
(16, ' A C structure or User defined datatype is also called ________.', ' Derived data type\r\n', 'Secondary data type', ' Aggregate data type', ' All the above', 4),
(17, 'Which of the following return-type cannot be used for a function in C?\r\na) char *\r\nb) struct\r\nc) void\r\nd) none of the mentioned', 'char *', 'struct', 'void', 'none of the mentioned', 4),
(18, ' Which of the following operation is illegal in structures?', 'Typecasting of structure', 'Pointer to a variable of the same structure', 'Dynamic allocation of memory for structure', 'All of the mentioned', 1),
(19, 'What is the use of size() operator?\r\n', 'To get the size of data types or variables in bytes', 'To get size of data types only', 'To get size of the variables only', 'All of the above', 1),
(20, 'What is the return type of the hashCode() method in the Object class?', 'Object', 'int', 'long', 'void', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(128) NOT NULL,
  `points` int(11) NOT NULL,
  `otp` int(11) NOT NULL,
  `quiz_score` int(11) NOT NULL DEFAULT 0,
  `level3` int(255) NOT NULL,
  `level4` int(245) NOT NULL,
  `int_level1` int(255) NOT NULL,
  `int_level2` int(255) NOT NULL,
  `int_level3` int(255) NOT NULL,
  `int_level4` int(255) NOT NULL,
  `exp_level1` int(255) NOT NULL,
  `exp_level2` int(255) NOT NULL,
  `exp_level3` int(255) NOT NULL,
  `exp_level4` int(255) NOT NULL,
  `allpoints` int(255) NOT NULL,
  `beginner_score` int(255) NOT NULL,
  `intermediate_score` int(255) NOT NULL,
  `expert_score` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `username`, `email`, `password`, `points`, `otp`, `quiz_score`, `level3`, `level4`, `int_level1`, `int_level2`, `int_level3`, `int_level4`, `exp_level1`, `exp_level2`, `exp_level3`, `exp_level4`, `allpoints`, `beginner_score`, `intermediate_score`, `expert_score`) VALUES
(1, 'karan', 'karan123@gmail.com', '123', 7, 0, 2, 5, 0, 2, 2, 2, 0, 0, 0, 0, 0, 20, 6, 6, 0),
(23, 'kevin', 'kevin@123', '$2y$10$Kd3mUWwvDxlNtFJDf2B6KOqAX.3X3TUL3Og38UINIvFYmFC5G147m', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(37, 'c', 'c@123', '$2y$10$3/kQitdBf4MtJzkrPEycReOqeTwlWov.CBXrCeUUSfl53lHitisXW', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(38, 'd', 'dineshd123@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(39, 'k', 'k@123', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(56, 'Kira', '123', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(57, 'abc', 'abc', 'abc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(58, 'cbc', 'cbc', 'cbc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(59, 'gopi', 'gopi@132', '4567', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(60, 'roja', 'roja@gmail.com', '$2y$10$FFLxkN9UBykEwgBX2rKn2OvemGwD2gA2fPJxBL46pPgNyoFey5oyK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(63, 'usha', 'usha@gmail.com', 'usha123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(64, 'hanu', 'hanu@gmail.com', 'hanu123', 6, 0, 1536, 4096, 0, 3, 1, 0, 0, 0, 0, 0, 0, 2826, 2822, 4, 0),
(65, 'naruto', 'naruto@gmail.com', '1234', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(67, 'arun', 'arun@mail.com', '123', 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0),
(68, 'Somu', 'somu@gmail.com', 'somu123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(69, 'gokul', 'gokul@gmail.com', '123', 6, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0),
(70, 'bharath', 'bharath@gmail.com', '123', 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0),
(71, 'lokesh', 'lokesh@gmail.com', '123', 8, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0),
(72, 'vivek', 'vivek@gmail.com', '123', 14, 0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 0, 0, 0),
(74, 'ram', 'ram@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(75, 'vishnu', 'vishnu@gmail.com', '113', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(76, 'ntr', 'ntr@gmail.com', '123', 8, 0, 10, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 0, 0, 0),
(77, 'Suhash', 'suhash@gmail.com', '123', 12, 0, 5, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 0, 0),
(78, 'raja', 'raja@gmail.com', '123', 14, 0, 9, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0),
(79, 'mani', 'mani@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(80, 'Sai', 'sai@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(81, 'Sekhar', 'sekhar@gmail.com', '123', 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0),
(82, 'suresh', 'suresh@saveetha.com', '123', 14, 0, 4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 0, 0, 0),
(83, 'raki', 'raki@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(84, 'Elamaran', 'elamaran@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(85, 'madhu', 'madhu@gmail.com', '123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_questionsexp`
--
ALTER TABLE `quiz_questionsexp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_questionsint`
--
ALTER TABLE `quiz_questionsint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `quiz_questionsexp`
--
ALTER TABLE `quiz_questionsexp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quiz_questionsint`
--
ALTER TABLE `quiz_questionsint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
